﻿ - Add-Migration "InitialDBCreation" -context SchoolContext
 - Update-Database